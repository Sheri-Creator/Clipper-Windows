@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" (
    call setup_and_run.bat
    exit /b
)
call venv\Scripts\activate.bat
start "" http://127.0.0.1:8765
venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8765
pause
