@echo off
setlocal
cd /d "%~dp0"
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo [WARNING] FFmpeg not found! Run: winget install Gyan.FFmpeg
    pause
    exit /b 1
)
if not exist "venv\Scripts\python.exe" python -m venv venv
call venv\Scripts\activate.bat
pip install --upgrade pip
pip install -r requirements.txt
start "" http://127.0.0.1:8765
venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8765
pause
